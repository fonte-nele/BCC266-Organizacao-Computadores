//import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import implementations.dm_kernel.user.JCL_FacadeImpl;
import interfaces.kernel.JCL_facade;
import interfaces.kernel.JCL_result;

public class Principal {
	
	private JCL_facade jcl;
	private int numeroDados;

	public static void main(String[] args) {
				
		new Principal();
	}
	
	public Principal(){
		
		
		/*  ----------MAQUINA DE FAZER MUSICA------------

		OPCODE DAS INSTRUCOES:

		 -1 - TOCA TODAS AS MUSICAS																				| 0 ADRESS
		  0 - TOCA UMA MUSICA 																					| 1 ADRESS
		  1 - BUSCA UMA MELODIA E SALVA EM MQ																	| 1 ADRESS
		  2 - BUSCA UMA MUSICA E ADICIONA A MELODIA DE MQ E SALVA TUDO NA POSIÇÃO DA MUSICA BISCADA				| 1 ADRESS
		  3 - SUBSTITUI UMA MUSICA PELA ULTIMA SLAVA EM MQ CRIADA PELA											| 1 ADRESS 							
		  4 - PARA A MAQUINA 																					| 0 ADRESS		
		----------------------------------------------*/
		
		jcl = JCL_FacadeImpl.getInstance();
		
		String [] memoriaInst = new String [100];
		memoriaInst = montarMemoriaInst();
		
		montarMemoriaDados();
		
		
		int PC=0;
		int IR = -1; //valor q indica opcode 
		int MAR = -1; // valor q indica endereco 
		String MBR = "";
		String MQ = "";
		
		//Registro das minhas tasks
		Boolean b = jcl.register(JCL_Tasks.class, "JCL_Tasks");
		System.err.println(b);	
		
		/*
		File f = new File("../jcl_useful_jars/TP.jar");
		File[] arg0 = {f};
		Boolean b = jcl.register(arg0, "JCL_Tasks");
		System.err.println(b);	
		*/
		
		List<String> tickets = new LinkedList<String>();
				
		while (IR!=4){
			MBR = memoriaInst[PC];//jcl.getValue("memoriaInst_"+PC).getCorrectResult().toString();
			
			String[] aux = MBR.split(":");
			
			IR = Integer.parseInt(aux[0]);
			MAR = Integer.parseInt(aux[1]);
			
			switch (IR){
				case -1: {
					Object[] args ={new Integer(numeroDados)};
					String ticket = jcl.execute("JCL_Tasks", "switchOpcao1", args);
					tickets.add(ticket);
					break;
				}
				case 0: {
					Object[] args ={new Integer(MAR)};
					String ticket = jcl.execute("JCL_Tasks", "switchOpcao2", args);
					tickets.add(ticket);
					break;
				}
				case 1: {
					Object[] args ={new Integer(MAR)};
					String ticket = jcl.execute("JCL_Tasks", "switchOpcao3", args);
					JCL_result jclr = jcl.getResultBlocking(ticket);
					MQ = jclr.getCorrectResult().toString();
					break;
				}
				case 2: {
					Object[] args ={new Integer(MAR), MQ};
					String ticket = jcl.execute("JCL_Tasks", "switchOpcao4", args);
					JCL_result jclr = jcl.getResultBlocking(ticket);
					MQ = jclr.getCorrectResult().toString();
					System.out.println(MQ);
					break;
				}
				case 3: {
					Object[] args ={new Integer(MAR), MQ};
					String ticket = jcl.execute("JCL_Tasks", "switchOpcao5", args);
					tickets.add(ticket);
					break;
				}
				case 4: {
					System.out.println("**MAQUINA TERMINADA!!**");
				}
			}
			
			PC++;
		}
		
		//PEGA OS ULTIMOS TICKETS 
		for(String str:tickets)
			jcl.getResultBlocking(str);

		//IMPRIME TODA MEMORIA DE DADOS
		Object[] args ={new Integer(numeroDados)};
		String ticket = jcl.execute("JCL_Tasks", "switchOpcao1", args);
		jcl.getResultBlocking(ticket);
		
		jcl.cleanEnvironment();
		
		System.exit(0);
	}
	
	private String[] montarMemoriaInst(){
		int j;
		String aleatorio;
		String[] memoriaInst = new String[100];
		Random r1 = new Random();
		Random r2 = new Random();
		for (j=0; j<99; j++){
			aleatorio = String.valueOf(r1.nextInt(4));
			aleatorio += ":" + String.valueOf(r2.nextInt(26));
			memoriaInst[j] = aleatorio;
		}
		aleatorio = "4:-1";
		memoriaInst[j] = aleatorio;
		return memoriaInst;
	}
	
	private void montarMemoriaDados(){
			
		jcl.instantiateGlobalVar("memoriaDados_0", "heavy metal");
		jcl.instantiateGlobalVar("memoriaDados_1", "hard rock");
		jcl.instantiateGlobalVar("memoriaDados_2", "power metal");
		jcl.instantiateGlobalVar("memoriaDados_3", "hardcore");
		jcl.instantiateGlobalVar("memoriaDados_4", "blues");
		jcl.instantiateGlobalVar("memoriaDados_5", "warpigs");
		jcl.instantiateGlobalVar("memoriaDados_6", "paranoid");
		jcl.instantiateGlobalVar("memoriaDados_7", "black dog");
		jcl.instantiateGlobalVar("memoriaDados_8", "stairway to heaven");
		jcl.instantiateGlobalVar("memoriaDados_9", "highway to the hell");
		jcl.instantiateGlobalVar("memoriaDados_10", "master of puppets");
		jcl.instantiateGlobalVar("memoriaDados_11", "rainning blood");
		jcl.instantiateGlobalVar("memoriaDados_12", "angel of death");
		jcl.instantiateGlobalVar("memoriaDados_13", "yellow submarinne");
		jcl.instantiateGlobalVar("memoriaDados_14", "for whom the bell tolls");
		jcl.instantiateGlobalVar("memoriaDados_15", "one");
		jcl.instantiateGlobalVar("memoriaDados_16", "paranoid");
		jcl.instantiateGlobalVar("memoriaDados_17", "black dog");
		jcl.instantiateGlobalVar("memoriaDados_18", "stairwaymaster of puppets");
		jcl.instantiateGlobalVar("memoriaDados_11", "rainni to heaven");
		jcl.instantiateGlobalVar("memoriaDados_19", "highway to the hell");
		jcl.instantiateGlobalVar("memoriaDados_20", "mastetor of puppets");
		jcl.instantiateGlobalVar("memoriaDados_21", "rtoainning blood");
		jcl.instantiateGlobalVar("memoriaDados_22", "antogel of death");
		jcl.instantiateGlobalVar("memoriaDados_23", "bluesto the hell");
		jcl.instantiateGlobalVar("memoriaDados_24", "warpigsblues");
		jcl.instantiateGlobalVar("memoriaDados_25", "oneblues");
		this.numeroDados = 25;
	}

}

